#  Project : Detection of Parkinson's Disease Using Vocal Features: An Eigen Approach
#  Filename : __init__.py
#  Author : thameem
#  Modified time : Thu, 24 Nov 2022 at 10:08 pm India Standard Time

from .classifiers import Classifiers
